<!DOCTYPE html>

<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <title>About Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
        <link href="/css/app.min.css?id=bc77b2e8ffce3978ddb01eeec11652f9" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
        crossorigin="anonymous"></script>

    <meta name="description"
        content="Shubhashish Homes is one of the top real estate builders and developers in Jaipur known for developing villas, flats/apartments in Jaipur.">
    <link rel="canonical" href="#">
    <meta property="og:locale" content="en_US">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Builders and Developers in Jaipur, Flats in Jaipur">
    <meta property="og:description"
        content="Shubhashish Homes is one of the top real estate builders and developers in Jaipur known for developing villas, flats/apartments in Jaipur.">
    <meta property="og:url" content="#">
    <meta property="og:site_name" content="Shubhashish Homes">
    <meta property="og:image" content="https://www.shubhashishhomes.com/img/logo/shubh_transparent.webp">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Live The Resort Lifestyle | 2&amp;3 BHK Luxury Apartments in Jaipur">
    <meta name="twitter:description"
        content="Shubhashish Homes is Jaipur's most innovative Real Estate Builder that lets you live a Resort Lifestyle Daily.">


    <!-- Google Tag Manager -->
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WBK5CTM');
    </script>
    <!-- End Google Tag Manager -->

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css'>
    <link rel="stylesheet" type="text/css" href="css/slick.css">
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/initial.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="css/skins/green.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">

    <link rel="apple-touch-icon" sizes="180x180" href="img/fav/apple-touch-icon.webp">
    <link rel="icon" type="image/png" sizes="32x32" href="img/fav/favicon-32x32.webp">
    <link rel="icon" type="image/png" sizes="16x16" href="img/fav/favicon-16x16.webp">

    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500;600;700;800&amp;display=swap"
        rel="stylesheet">


</head>

<!-- Chat Icon -->
<!-- Chat Icon -->
<div id="chat-icon" onclick="toggleChat()">
    <img src="https://cdn-icons-png.flaticon.com/512/2462/2462719.png" alt="Chat Icon" />
</div>

<!-- Chat Box -->
<div id="chat-box">
    <div id="chat-header">💬 The Golden Estatess</div>
    <div id="chat-body">
        <div class="chat-message bot">Welcome to The Golden Estatess 👋<br>Please fill the enquiry form below:</div>
        <form id="enquiry-form">
            <div class="form-group">
                <label for="name">Your Name</label>
                <input type="text" id="name" required />
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" required />
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" required />
            </div>
            <div class="form-group">
                <label for="message">Your Query</label>
                <textarea id="message" rows="3" required></textarea>
            </div>
            <button type="submit">Submit</button>
        </form>
        <div id="thank-you" style="display: none;">
            <p>✅ Thank you! We’ll contact you shortly.</p>
        </div>
    </div>
</div>

<!-- Chat Styles -->
<style>
    #chat-icon {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #000;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        padding: 10px;
        cursor: pointer;
        z-index: 9999;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease;
    }

    #chat-icon img {
        width: 100%;
        height: 100%;
        filter: invert(1);
        /* Makes the icon white */
        object-fit: contain;
    }

    #chat-icon:hover {
        transform: scale(1.1);
    }

    #chat-box {
        display: none;
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 320px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 9999;
        overflow: hidden;
        animation: fadeIn 0.3s ease-in-out;
    }

    #chat-header {
        background: #000;
        color: #fff;
        padding: 12px 16px;
        font-weight: bold;
        font-size: 18px;
    }

    #chat-body {
        padding: 16px;
    }

    .chat-message.bot {
        background: #f1f1f1;
        padding: 10px 12px;
        border-radius: 10px;
        margin-bottom: 15px;
        font-size: 14px;
    }

    .form-group {
        margin-bottom: 12px;
    }

    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 5px;
        font-size: 14px;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;
        padding: 8px 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 14px;
    }

    button[type="submit"] {
        background: #000;
        color: #fff;
        border: none;
        padding: 10px 14px;
        border-radius: 6px;
        font-size: 15px;
        cursor: pointer;
        width: 100%;
        margin-top: 10px;
    }

    button[type="submit"]:hover {
        background: #333;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

<!-- Chat Script -->
<script>
    function toggleChat() {
        const box = document.getElementById("chat-box");
        box.style.display = box.style.display === "none" ? "block" : "none";
    }

    document.getElementById("enquiry-form").addEventListener("submit", function (e) {
        e.preventDefault();
        // You can add AJAX/fetch call here for backend processing

        document.getElementById("enquiry-form").style.display = "none";
        document.getElementById("thank-you").style.display = "block";
    });
</script>


<body class="home_page">



    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WBK5CTM" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->


    <!-- Main header start -->
     <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap Navbar</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand" href="#">
      <img src="WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview (1).png" alt="Logo" height="50">
    </a>

    <!-- Toggle Button -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
      aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="mainNavbar">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>

        <!-- Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="projectsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Projects
          </a>
          <ul class="dropdown-menu" aria-labelledby="projectsDropdown">
            <li><a class="dropdown-item" href="chakra.php">Chekra</a></li>
            <li><a class="dropdown-item" href="behra.php">Behra</a></li>
            <li><a class="dropdown-item" href="binda.php">Binda</a></li>
          </ul>
        </li>

        <li class="nav-item"><a class="nav-link" href="blogs.php">Blogs</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>

        <!-- Enquiry Button -->
        <li class="nav-item">
          <a href="enquiry.php" class="btn btn-danger ms-lg-3">Enquiry Now</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
    <!-- Sidenav end -->


   <section class="breadcrumb_section">
        <div class="home_slider">
            <img src="https://static.vecteezy.com/system/resources/previews/010/195/978/non_2x/real-estate-agent-holding-house-key-to-his-client-after-signing-contract-concept-for-business-loan-investment-mortgage-real-estate-moving-home-or-renting-property-banner-with-copy-space-photo.jpg" alt="Shubhashish Homes">
            <div class="overlap-bread">
                <div class="container">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="javascript:;">About Golden Estate</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Banner end -->


    <script>
        function fchangeType(val) {
            //   alert();
            var txtprojectid = 1;
            $.ajax({
                url: 'ajaxdd.asp?id=' + val,
                data: {
                    txtprojectid: txtprojectid
                },
                success: function (data) {
                    $("#divsel").html(data);
                    if (data == "success") { }
                }
            });
            $.ajax({
                url: 'ajaxdd1.asp?id=' + val,
                data: {
                    txtprojectid: txtprojectid
                },
                success: function (data) {
                    $("#divsel1").html(data);
                    if (data == "success") { }
                }
            });
        }
    </script>
   


    


    <!-- Bootstrap 5 CSS (if not already added) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        .project-img-box {
            position: relative;
            overflow: hidden;
            border-radius: 8px;
        }

        .project-img-box img {
            width: 100%;
            height: 350px;
            object-fit: cover;
            border-radius: 8px;
        }

        .project-img-box span {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 10px 15px;
            background: rgba(0, 0, 0, 0.6);
            color: #fff;
            font-weight: 600;
            text-align: center;
            font-size: 1rem;
            border-radius: 0 0 8px 8px;
        }

        .title-border {
            display: flex;
            gap: 6px;
            margin: 10px 0 20px;
        }

        .title-border-inner {
            width: 30px;
            height: 4px;
            background-color: #000;
        }

        .btn-4 {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            display: inline-block;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }
    </style>


    <!-- HTML Section -->
    <section class="about_sec py-5">
        <div class="container">
            <div class="row align-items-center gy-4">

                <!-- Left Text Content -->
                <div class="col-lg-6">
                    <div class="about_sec_left">
                        <h1 class="section-title">The Golden Estates: <br>A GLANCE</h1>
                        <div class="title-border">
                            <div class="title-border-inner"></div>
                            <div class="title-border-inner"></div>
                            <div class="title-border-inner"></div>
                        </div>
                        <h5>
                            Kailash Tower, a groundbreaking residential building project, nestled in Narayanpuri, Sirsi
                            Road, Jaipur.
                            This architectural marvel redefines modern living with its unparalleled elegance and premium
                            features.
                            The thoughtfully crafted interiors boast spacious layouts, high-end finishes, and an
                            ambiance that resonates
                            with comfort and style. Strategically located, Kailash Tower provides convenient access to
                            key amenities,
                            educational institutions, and business centers.
                        </h5>
                        <a href="about-us" class="btn-4">Read More</a>
                    </div>
                </div>

                <!-- Right Single Image -->
                <div class="col-lg-6">
                    <div class="project-img-box">
                        <img src="WhatsApp Image 2025-07-14 at 5.15.45 PM.jpeg" alt="Kailash Tower Image">
                    </div>
                </div>

            </div>
        </div>
    </section>




    <!-- Counters 2 strat -->
   
    <!-- Counters 2 end -->


    <!-- Featured properties start -->
 
    <!-- Featured properties end -->


    <!-- testimonial 3 start  -->
    

    <style>
        .responsive-video-wrapper {
            position: relative;
            padding-bottom: 56.25%;
            /* 16:9 aspect ratio */
            padding-top: 25px;
            height: 0;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .responsive-video-wrapper video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* Ensures good clarity without distortion */
        }
    </style>


    <!-- testimonial 3 end -->

    <!-- Blog start -->
 <!-- Font Awesome CDN (add in <head> if not already added) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

<div class="content-area">
    <div class="container">
        <div class="main-title-5 text-center">
            <h1>Innovations and Priorities</h1>
            <div class="title-border">
                <div class="title-border-inner"></div>
                <div class="title-border-inner"></div>
                <div class="title-border-inner"></div>
            </div>
        </div>

        <div class="row justify-content-center iwc_box_row">
            <!-- Box 1 -->
            <div class="col-lg-6">
                <div class="iwc_box">
                    <div class="icon_wrap text-center">
                        
                        <!-- Optional Icon -->
                        <i class="fas fa-recycle fa-2x text-success mt-2"></i>
                        <h4 class="mt-3">Garbage Segregation at <br> The Source</h4>
                    </div>
                    <p>At The Golden Realestate, we support sustainable living through garbage segregation at the source. By encouraging residents to separate recyclables and organic waste, we promote eco-conscious habits, contributing to a cleaner environment and healthier communities.</p>
                </div>
            </div>

            <!-- Box 2 -->
            <div class="col-lg-6">
                <div class="iwc_box">
                    <div class="icon_wrap text-center">
                       
                        <i class="fas fa-charging-station fa-2x text-warning mt-2"></i>
                        <h4 class="mt-3">EV Charging</h4>
                    </div>
                    <p>The Golden Realestate embraces the future of transportation by offering EV charging facilities for each unit. Our sustainability pledge extends beyond housing, supporting the transition to electric vehicles.</p>
                </div>
            </div>

            <!-- Box 3 -->
            <div class="col-lg-6">
                <div class="iwc_box">
                    <div class="icon_wrap text-center">
                        
                        <i class="fas fa-tachometer-alt fa-2x text-primary mt-2"></i>
                        <h4 class="mt-3">Smart Water Meter</h4>
                    </div>
                    <p>The Golden Realestate integrates smart water meters into properties. These innovative devices enable precise water usage monitoring, promoting responsible consumption and efficiency.</p>
                </div>
            </div>

            <!-- Box 4 -->
            <div class="col-lg-6">
                <div class="iwc_box">
                    <div class="icon_wrap text-center">
                      
                        <i class="fas fa-smile-beam fa-2x text-info mt-2"></i>
                        <h4 class="mt-3">Customer Delight <br> Practices</h4>
                    </div>
                    <p>We go beyond satisfaction, striving for delight in every interaction. Through personalised service and attention to detail, we create memorable experiences that build long-term trust.</p>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Blog end -->


   


    <script>
        function capref2() {
            d1 = new Date();
            // alert()
            $("#myimgcapt2").attr("src", "aspcaptcha1.asp?" + d1.getTime());
        }

        function submitformpage() {
            $("#enquireFor2,#namenew,#emailnew,#phonenew,#strCAPTCHA1").css("border-bottom", "1px solid #000");
            var enquireFor2 = $("#enquireFor2").val();
            var namenew = $("#namenew").val();
            var emailnew = $("#emailnew").val();
            var phonenew = $("#phonenew").val();

            var contect_mode = ($('input[type=radio][name=contect_mode]:checked').val());

            var offers = "";
            if ($("#offers").is(':checked')) {
                var offers = $("#offers").val();
            }

            var agree = $("#agree").is(':checked');

            var strCAPTCHA1 = $("#strCAPTCHA1").val();


            var counter = 0;

            if (enquireFor2 == "0") {
                $("#enquireFor2").css("border-bottom", "2px solid red");
                $("#enquireFor2").focus();
                counter = 1;
                return false;
            }

            if (namenew == "") {
                $("#namenew").css("border-bottom", "1px solid red");
                $("#namenew").focus();
                counter = 1;
                return false;
            }

            if (emailnew == "") {
                $("#emailnew").css("border-bottom", "1px solid red");
                $("#emailnew").focus();
                counter = 1;
                return false;
            }

            if (IsEmail(emailnew) == false) {
                $("#emailnew").css("border-bottom", "1px solid red");
                $("#emailnew").focus();
                counter = 1;
                return false;
            }

            if (phonenew == "") {
                $("#phonenew").css("border-bottom", "1px solid red");
                $("#phonenew").focus();
                counter = 1;
                return false;
            }


            if (IsNumericMobile(phonenew) == false) {
                $("#phonenew").css("border-bottom", "1px solid red");
                $("#phonenew").focus();
                counter = 1;
                return false;
            }


            if (agree == false) {
                alert("Please select the checkbox to agree Privacy policy.");
                counter = 1;
                return false;
            }

            if (strCAPTCHA1 == "") {
                $("#strCAPTCHA1").css("border", "1px solid red");
                $("#strCAPTCHA1").focus();
                counter = 1;
                return false;
            }

            if (counter == 0) {

                $("#lblProcessForm1").html("Please wait...");
                $.ajax({
                    url: 'ajaxSubmitEnquirePage.asp',
                    data: {
                        enquireFor2: enquireFor2,
                        namenew: namenew,
                        emailnew: emailnew,
                        phonenew: phonenew,
                        strCAPTCHA1: strCAPTCHA1,
                        contect_mode: contect_mode,
                        offers: offers
                    },
                    success: function (data) {
                        capref2();
                        if (data == "success") {
                            document.location.href = "thankyou";
                            $("#namenew,#emailnew,#phonenew,#offers,#strCAPTCHA1").val('');
                        } else {
                            $("#lblProcessForm1").html(data)
                        }

                    }
                });

            }

        }

        function validatefmpage() {


            $("#enquireFor2,#namenew,#emailnew,#phonenew,#contect_mode,#strCAPTCHA1").css("border-bottom", "1px solid #ccc");
            var enquireFor2 = $("#enquireFor2").val();
            var namenew = $("#namenew").val();
            var emailnew = $("#emailnew").val();
            var phonenew = $("#phonenew").val();

            if (enquireFor2 == "0") {
                $("#enquireFor2").css("border-bottom", "2px solid red");
                $("#enquireFor2").focus();
                counter = 1;
                return false;
            }


            if (namenew == "") {
                $("#namenew").css("border-bottom", "1px solid red");
                $("#namenew").focus();
                return false;
            }

            if (emailnew == "") {
                $("#emailnew").css("border-bottom", "1px solid red");
                $("#emailnew").focus();

                return false;
            }
            if (IsEmail(emailnew) == false) {
                $("#emailnew").css("border-bottom", "1px solid red");
                $("#emailnew").focus();

                return false;
            }

            if (phonenew == "") {
                $("#phonenew").css("border-bottom", "1px solid red");
                $("#phonenew").focus();
                return false;
            }

            if (IsNumericMobile(phonenew) == false) {
                $("#phonenew").css("border-bottom", "1px solid red");
                $("#phonenew").focus();
                counter = 1;
                return false;
            }

            if (strCAPTCHA1 == "") {
                $("#strCAPTCHA1").css("border", "1px solid red");
                $("#strCAPTCHA1").focus();
                bugCnt = bugCnt + 1;
                return false;
            }
            return true;

        }


        function IsEmail(emailnew) {
            var regex = /^([a-zA-Z0-9_.+])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(emailnew);
        }

        function IsNumericMobile(input) {
            var RE = /\(?([5-9]{1})\)?([ .-]?)([0-9]{5})\2([0-9]{4})/;
            return (RE.test(input));
        }
    </script>
    
                   <div class="footer">
    <div class="container">
        <div class="row py-5 custom-padding align-items-start">

            <!-- Brand & Contact -->
            <div class="col-12 col-md-5 mb-4 mb-md-0">
                <div class="footer-brand">
                    <h3 style="color:white">Solwave Enterprises</h3>
                    <p class="footer-slogan">
                        Rooftop solar made simple. We don't just sell solar — we give you peace of mind.
                    </p>
                </div>

                <!-- Contact Info -->
                <div class="footer-contact mt-4">
                    <div class="d-flex align-items-center mb-2">
                        <i class="fa fa-phone me-2"></i>
                        <a href="tel:+919351953802">+91 9351953802</a>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <i class="fa fa-envelope me-2"></i>
                        <a href="/cdn-cgi/l/email-protection#87f4e8ebf1e2e2e9f3e2f5f7f5eef4e2f4a9e4e8ea">solveenterprises.com</a>
                    </div>

                    <!-- Social Icons -->
                    <div class="footer-social mt-3 d-flex gap-3">
                        <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                        <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                        <a href="https://www.instagram.com/solwave.enterprises2025/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.linkedin.com/in/solwave-enterprises-252065375/" target="_blank"><i class="fa fa-linkedin"></i></a>
                    </div>
                </div>

                <!-- Address for Mobile -->
                <div class="footer-address mt-4 d-md-none">
                    E-52, Amrapali Marg, Vaishali Nagar, Jaipur-302021
                </div>
            </div>

            <!-- Links -->
            <div class="col-12 col-md-7 footer-links">
                <div class="row">
                    <div class="col-6 col-md-4 mb-3 mb-md-0">
                        <h5 style="color:white">Our Projects</h5>
                        <ul>
                            <li><a href="index.php">Homes</a></li>
                            <li><a href="commercial.php">Commercial</a></li>
                            <li><a href="jjm.php">JJM</a></li>
                        </ul>
                    </div>
                    <div class="col-6 col-md-4 mb-3 mb-md-0">
                        <h5 style="color:white">Quick Links</h5>
                        <ul>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="blogs.php">Blogs</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-4">
                        <h5 style="color:white">Others</h5>
                        <ul>
                            <li><a href="chekra.php">Chekra Solar</a></li>
                            <li><a href="binda.php">Binda</a></li>
                            <li><a href="behra.php">Behra</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Address for Desktop -->
                <div class="footer-address mt-4 d-none d-md-block">
                    E-52, Amrapali Marg, Vaishali Nagar, Jaipur-302021
                </div>
            </div>

            <!-- Copyright -->
            <div class="col-12 text-center mt-4">
                <p>&copy; 2025 Solwave Enterprises. Designed by Research And Development IT Solutions.</p>
            </div>
        </div>
    </div>
</div>

<style>
/* Footer Main */
.footer {
    background: hsl(353.22deg 57.79% 39.02%);
    color: #fff;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    padding-top: 40px;
}

.footer h3, .footer h5 {
    color: #ff5e78;
}

.footer h5 {
    font-weight: 600;
    margin-bottom: 15px;
}

.footer a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease, transform 0.3s ease;
}

.footer a:hover {
    color: #ff5e78;
    transform: translateY(-2px);
}

.footer-slogan {
    font-size: 15px;
    line-height: 1.6;
}

.footer-contact i {
    color: #ff5e78;
    font-size: 18px;
}

.footer-social i {
    font-size: 20px;
    color: #fff;
    transition: color 0.3s, transform 0.3s;
}

.footer-social i:hover {
    color: #ff5e78;
    transform: scale(1.2);
}

.footer ul {
    list-style: none;
    padding: 0;
}

.footer ul li {
    margin-bottom: 8px;
}

.footer-address {
    font-size: 14px;
    margin-top: 10px;
    color: #aaa;
}

@media (max-width: 767px) {
    .footer-links .col-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }
    .footer h3 {
        text-align: center;
    }
    .footer-slogan {
        text-align: center;
    }
    .footer-social {
        justify-content: center;
    }
}
</style>


    


    <div id="page_scroller"><i class="fa fa-chevron-up"></i></div>
    <div class="fixed_enquiry" onclick="enquire_func('','')">Enquire Now</div>


   <div class="modal_popup popshow" id="enquiry_form">
        <div class="modal_popup_in">

            <div class="modal_container">
                <span class="popup_close">✖</span>
                <h1>Enquire Now</h1>
                <form action="#" method="POST" onSubmit="return validatefm();">
                    <div class="form_control">
                        <!-- <label>Enquire For</label> -->


                        <select name="enquireFor" id="enquireFor" class="form_input">
                            <option value="0" selected>Project Name *</option>
                            <option value="Shubhashish Geeta">Shiv Bihar</option>
                            <option value="Shubhashish Prakash">Gulab Badi</option>
                            <option value="Shubhashish Marina">KB Empire</option>
                            <option value="Shubhashish Forest">Tanishak Empire</option>
                            <option value="Shubhashish Forest">Kailash Tower</option>
                        </select>
                    </div>
                    <div class="form_control">
                        <input placeholder="Name *" type="text" name="namebox" id="namebox" class="form_input">
                    </div>
                    <div class="form_control">
                        <input placeholder="Email *" type="email" id="emailbox" name="emailbox" class="form_input">
                    </div>
                    <div class="form_control">
                        <input class="form_input" id="phonebox" name="phonebox" minlength="1" maxlength="10" type="text"
                            placeholder="Mobile Number *">
                    </div>
                    <div class="form_control">
                        <textarea name="messagebox" id="messagebox" cols="30" rows="10" class="form_input"
                            placeholder="Message *"></textarea>
                    </div>

                    <div class="form_control main-cpt">
                        <img id="myimgcapt" src="aspcaptcha.asp" alt="Captcha"><a href="javascript:capref1()"><i
                                class="fa-solid fa-rotate"></i></a>
                        <span>Please Enter Code:</span>
                        <input name="strCAPTCHA" type="text" placeholder="Enter Captcha *" class="inp form_input"
                            id="strCAPTCHA" size="10">
                    </div>


                    <div class="form_control">
                        <input class="btn-4" id="btnSubmit" type="button" onClick="javascript:submitformcontactSF();"
                            name="submit" value="Submit">

                    </div>

                    <div id="lblProcessForm" style="color: red;"></div>



                    <div class="note">
                        <p>
                            Call us for more information at <span>+91 89490 46678</span>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <input type="hidden" name="txtfromclick" id="txtfromclick" value="">

    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
        function capref1() {
            d = new Date();
            $("#myimgcapt").attr("src", "aspcaptcha.asp?" + d.getTime());
        }


        function submitformcontact() {
            $("#enquireFor,#namebox,#emailbox,#phonebox,#messagebox").css("border-bottom", "2px solid #ccc");
            var enquireFor = $("#enquireFor").val();
            var namebox = $("#namebox").val();
            var emailbox = $("#emailbox").val();
            var phonebox = $("#phonebox").val();
            var messagebox = $("#messagebox").val();
            var strCAPTCHA = $("#strCAPTCHA").val();
            //alert(packval);
            var counter = 0;

            if (enquireFor == "0") {
                $("#enquireFor").css("border-bottom", "2px solid red");
                $("#enquireFor").focus();
                counter = 1;
                return false;
            }


            if (namebox == "") {
                $("#namebox").css("border-bottom", "2px solid red");
                $("#namebox").focus();
                counter = 1;
                return false;
            }

            if (emailbox == "") {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();
                counter = 1;
                return false;
            }

            if (IsEmail(emailbox) == false) {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();
                counter = 1;
                return false;
            }

            if (phonebox == "") {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                counter = 1;
                return false;
            }


            if (IsNumericMobile(phonebox) == false) {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                counter = 1;
                return false;
            }


            if (messagebox == "") {
                $("#messagebox").css("border-bottom", "2px solid red");
                $("#messagebox").focus();
                counter = 1;
                return false;
            }

            if (strCAPTCHA == "") {
                $("#strCAPTCHA").css("border", "2px solid red");
                $("#strCAPTCHA").focus();
                bugCnt = bugCnt + 1;
                return false;
            }

            if (counter == 0) {

                $("#lblProcessForm").html("Processing... Please wait...");
                $("#btnSubmit").attr("disabled", true);
                $.ajax({
                    url: 'ajaxSubmitEnquirePopup.asp',
                    data: {
                        enquireFor: enquireFor,
                        namebox: namebox,
                        emailbox: emailbox,
                        phonebox: phonebox,
                        messagebox: messagebox,
                        strCAPTCHA: strCAPTCHA
                    },
                    success: function (data) {
                        if (data == "success") {
                            $("#namebox,#emailbox,#phonebox,#messagebox").val('');
                            window.location.href = "thankyou.asp?page=formcontact";
                        } else {
                            $("#lblProcessForm").html(data);
                        }
                    }
                });

            }

        }


        function submitformcontactSF() {
            $("#enquireFor,#namebox,#emailbox,#phonebox,#messagebox").css("border-bottom", "2px solid #ccc");
            var enquireFor = $("#enquireFor").val();
            var namebox = $("#namebox").val();
            var emailbox = $("#emailbox").val();
            var phonebox = $("#phonebox").val();
            var messagebox = $("#messagebox").val();
            var strCAPTCHA = $("#strCAPTCHA").val();
            //alert(packval);
            var counter = 0;

            if (enquireFor == "0") {
                $("#enquireFor").css("border-bottom", "2px solid red");
                $("#enquireFor").focus();
                counter = 1;
                return false;
            }


            if (namebox == "") {
                $("#namebox").css("border-bottom", "2px solid red");
                $("#namebox").focus();
                counter = 1;
                return false;
            }

            if (emailbox == "") {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();
                counter = 1;
                return false;
            }

            if (IsEmail(emailbox) == false) {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();
                counter = 1;
                return false;
            }

            if (phonebox == "") {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                counter = 1;
                return false;
            }


            if (IsNumericMobile(phonebox) == false) {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                counter = 1;
                return false;
            }


            if (messagebox == "") {
                $("#messagebox").css("border-bottom", "2px solid red");
                $("#messagebox").focus();
                counter = 1;
                return false;
            }

            if (strCAPTCHA == "") {
                $("#strCAPTCHA").css("border", "2px solid red");
                $("#strCAPTCHA").focus();
                bugCnt = bugCnt + 1;
                return false;
            }

            if (counter == 0) {

                $("#lblProcessForm").html("Please wait...");
                $.ajax({
                    url: 'ajaxSubmitEnquirePopup.asp',
                    data: {
                        enquireFor: enquireFor,
                        namebox: namebox,
                        emailbox: emailbox,
                        phonebox: phonebox,
                        messagebox: messagebox,
                        strCAPTCHA: strCAPTCHA
                    },
                    success: function (data) {
                        if (data == "success") {
                            $("#namebox,#emailbox,#phonebox,#messagebox,#strCAPTCHA").val('');
                            window.location.href = "thankyou.asp?page=formcontact";
                        } else if (data = "wrongcaptchamain") {
                            $("#lblProcessForm").html("Wrong Captcha Please try again!");
                            capref1();
                        } else {
                            $("#lblProcessForm").html(data);
                        }
                    }
                });

            }

        }

        function validatefm() {

            $("#enquireFor,#namebox,#emailbox,#phonebox,#messagebox").css("border-bottom", "2px solid #ccc");

            var enquireFor = $("#enquireFor").val();
            var namebox = $("#namebox").val();
            var emailbox = $("#emailbox").val();
            var phonebox = $("#phonebox").val();
            var messagebox = $("#messagebox").val();


            if (enquireFor == "") {
                $("#enquireFor").css("border-bottom", "2px solid red");
                $("#enquireFor").focus();
                return false;
            }

            if (namebox == "") {
                $("#namebox").css("border-bottom", "2px solid red");
                $("#namebox").focus();
                return false;
            }

            if (emailbox == "") {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();

                return false;
            }
            if (IsEmail(emailbox) == false) {
                $("#emailbox").css("border-bottom", "2px solid red");
                $("#emailbox").focus();

                return false;
            }

            if (phonebox == "") {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                return false;
            }

            if (IsNumericMobile(phonebox) == false) {
                $("#phonebox").css("border-bottom", "2px solid red");
                $("#phonebox").focus();
                counter = 1;
                return false;
            }

            if (messagebox == "") {
                $("#messagebox").css("border-bottom", "2px solid red");
                $("#messagebox").focus();
                return false;
            }

            return true;

        }


        function IsEmail(emailbox) {
            var regex = /^([a-zA-Z0-9_.+])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(emailbox);
        }

        function IsNumericMobile(input) {
            var RE = /\(?([5-9]{1})\)?([ .-]?)([0-9]{5})\2([0-9]{4})/;
            return (RE.test(input));
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <!-- <script  src="js/app.js"></script> -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/intlTelInput-jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js'></script>
    <script src="js/custom.js"></script>

    <script>
        // Country Code Selection
        $("#mobile_code").intlTelInput({
            initialCountry: "in",
            separateDialCode: true,
        });

        $('#drawer').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
        $('#dismiss').on('click', function () {
            $('#sidebar').removeClass('active');
        });

        $(document).on('click', function (e) {
            if (!$(e.target).closest('.rera_info, .rera_no_box_wrap').length) {
                $('.rera_no_box_wrap').removeClass('move');
            }
        });

        $('.rera_info').click(function (e) {
            e.stopPropagation(); // prevent document click from firing
            $('.rera_no_box_wrap').toggleClass('move');
        });


        // Mobile Menu Dropdown
        var level1 = $('.level1 > li > a');
        var level2 = $('.level2 > li > a');
        var level3 = $('.level3 > li > a');

        function clickvalue(varvalue) {
            $(varvalue).click(function () {
                $(this).toggleClass('open');
                $(this).parent('li').prevAll('li').children('ul').slideUp();
                $(this).parent('li').nextAll('li').children('ul').slideUp();
                $(this).parent('li').prevAll('li').children('a').removeClass('open');
                $(this).parent('li').nextAll('li').children('a').removeClass('open');
                $(this).next('ul').slideToggle();
            });
        }
        clickvalue(level1);
        clickvalue(level2);
        clickvalue(level3);
    </script>
    <script>
        $('.properties').click(function () {
            $('#search-style-2').fadeIn();
        })
        $('.search_close').click(function () {
            $('#search-style-2').fadeOut();
        })

        function tabFunction(tabpill, tab_container) {
            $(tabpill + ':first-child').addClass('active');
            $(tab_container).hide();
            $(tab_container + ':first').show();
            // Click function
            $(tabpill).click(function () {
                $(tabpill).removeClass('active');
                $(this).addClass('active');
                $(tab_container).hide();

                var activeTab = $(this).find('a').attr('href');
                $(activeTab).fadeIn();
                return false;
            });
        }

        tabFunction('.career_tab li', '.career_tab_container');
        tabFunction('#tabs-nav li', '.tab-content');
        tabFunction('.gallery_tab li', '.gallery_content');

        $('#select_month').change(function () {
            var select = $(this).find(':selected').val();
            $(".career_video_container").hide();
            $('#' + select).show();
        }).change();

        // Show the first tab and hide the rest
        $('#mneu_tabs_nav li:first-child').addClass('active');
        $('.menu_content').hide();
        $('.menu_content:first').show();

        // Click function

        $('#mneu_tabs_nav li').click(function () {
            $('#mneu_tabs_nav li').removeClass('active');
            $(this).addClass('active');
            $('.menu_content').hide();

            var activeTab = $(this).find('a').attr('href');
            $(activeTab).fadeIn();
            return false;
        });


        // $('.home_testinoial_slider').owlCarousel({
        //     items: 1,
        //     loop: false,
        //     margin: 0,
        //     nav: true,
        //     autoplay: true,
        //     smartSpeed: 1000,
        //     autoplaySpeed: 500,
        //     autoplayTimeout:30000,
        //     autoplayHoverPause:true,
        //     stagePadding: 0,
        //     nav: false,
        //     dots: true,
        //     navText: ["<i class='fa-solid fa-arrow-left-long'></i>", "<i class='fa-solid fa-arrow-right-long'></i>"],
        // });



        $('.new_project_slider.owl-carousel').owlCarousel({
            items: 3,
            loop: true,
            margin: 50,
            nav: true,
            autoplay: true,
            smartSpeed: 1000,
            autoplaySpeed: 500,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            center: true,
            stagePadding: 130,
            nav: true,
            dots: false,
            navText: ["<i class='fa-solid fa-arrow-left-long'></i>", "<i class='fa-solid fa-arrow-right-long'></i>"],
            responsive: {
                0: {
                    items: 1,
                    margin: 10,
                    stagePadding: 0,
                    center: false,
                },
                480: {
                    items: 2,
                    margin: 10,
                    stagePadding: 0,
                    center: false,
                },
                767: {
                    items: 2,
                    margin: 10,
                    stagePadding: 50,
                    center: true,
                },
                992: {
                    items: 2
                }
            }
        });


        $('.home_project_slider.owl-carousel').owlCarousel({
            items: 1,
            loop: true,
            margin: 0,
            nav: true,
            autoplay: true,
            smartSpeed: 1000,
            autoplaySpeed: 500,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            center: true,
            stagePadding: 0,
            nav: true,
            dots: false,
            navText: ["<i class='fa-solid fa-arrow-left-long'></i>", "<i class='fa-solid fa-arrow-right-long'></i>"],
        });

        $('.about_overview_slider.owl-carousel').owlCarousel({
            items: 1,
            loop: true,
            margin: 0,
            nav: true,
            autoplay: true,
            smartSpeed: 1000,
            autoplaySpeed: 500,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            center: true,
            stagePadding: 0,
            nav: true,
            dots: false,
            navText: ["<i class='fa-solid fa-arrow-left-long'></i>", "<i class='fa-solid fa-arrow-right-long'></i>"],
        });




        $(".word_limit").text(function (index, currentText) {
            var maxLength = $(this).attr('data-maxlength');
            if (currentText.length >= maxLength) {
                return currentText.substr(0, maxLength) + "...";
            } else {
                return currentText
            }
        });

        function enquire_func() {

            $('#enquiry_form').fadeToggle();
        }

        function enquire_funcPlans(fromwhere, projecttitle) {
            $("#fromwhere").val(fromwhere);
            $("#projecttitle").val(projecttitle);
            $('#enquiry_form').fadeToggle();
        }
        $(document).ready(function () {
            $('.modal_popup .popup_close').click(function () {
                $('.modal_popup').fadeOut();
            })
        })
    </script>

    <script>
        let video = document.querySelector('video');
        const btn_mute = document.querySelector('.btn-mute');
        const status = () => {
            if (video.muted) {
                btn_mute.classList.remove('active');
            } else {
                btn_mute.classList.add('active');
            }
        }
        btn_mute.onclick = () => {
            video.muted = !video.muted;
            status();
        }
        status();
    </script>



    <script>
        function capref12() {
            d = new Date();
            $("#myimgcapt1").attr("src", "aspcaptcha1.asp?" + d.getTime());
        }

        function con_submitformcontact() {
            $("#enquireFor3,#con_namebox,#con_emailbox,#con_phonebox,#con_messagebox,#terms2").css("border-bottom", "1px solid #ccc");
            var enquireFor3 = $("#enquireFor3").val();
            var con_namebox = $("#con_namebox").val();
            var con_emailbox = $("#con_emailbox").val();
            var con_phonebox = $("#con_phonebox").val();
            var con_messagebox = $("#con_messagebox").val();
            var terms2 = $("#terms2").is(':checked');
            var strCAPTCHA1 = $("#strCAPTCHA1").val();

            //alert(packval);
            var counter = 0;

            if (enquireFor3 == "0") {
                $("#enquireFor3").css("border-bottom", "2px solid red");
                $("#enquireFor3").focus();
                counter = 1;
                return false;
            }
            if (con_namebox == "") {
                $("#con_namebox").css("border-bottom", "1px solid red");
                $("#con_namebox").focus();
                counter = 1;
                return false;
            }

            if (con_emailbox == "") {
                $("#con_emailbox").css("border-bottom", "1px solid red");
                $("#con_emailbox").focus();
                counter = 1;
                return false;
            }

            if (IsEmail(con_emailbox) == false) {
                $("#con_emailbox").css("border-bottom", "1px solid red");
                $("#con_emailbox").focus();
                counter = 1;
                return false;
            }


            if (con_phonebox == "") {
                $("#con_phonebox").css("border-bottom", "1px solid red");
                $("#con_phonebox").focus();
                counter = 1;
                return false;
            }


            if (IsNumericMobile(con_phonebox) == false) {
                $("#con_phonebox").css("border-bottom", "1px solid red");
                $("#con_phonebox").focus();
                counter = 1;
                return false;
            }


            if (con_messagebox == "") {
                $("#con_messagebox").css("border-bottom", "1px solid red");
                $("#con_messagebox").focus();
                counter = 1;
                return false;
            }
            if (terms2 == false) {
                $("#terms2").css("border", "1px solid red").focus();
                $("#lblProcessForm1").html('Please give your consent.');
                counter = 1;
                return false;
            }

            if (strCAPTCHA1 == "") {
                $("#strCAPTCHA1").css("border", "1px solid red");
                $("#strCAPTCHA1").focus();
                counter = 1;
                return false;
            }


            if (counter == 0) {

                $("#lblProcessForm1").html("Please wait...");
                $.ajax({
                    url: 'ajaxSubmitContact.asp',
                    data: {
                        enquireFor3: enquireFor3,
                        con_namebox: con_namebox,
                        con_emailbox: con_emailbox,
                        con_phonebox: con_phonebox,
                        con_messagebox: con_messagebox,
                        strCAPTCHA1: strCAPTCHA1
                    },
                    success: function (data) {
                        capref12();
                        if (data == "success") {
                            $("#con_namebox,#con_emailbox,#con_subject,#con_phonebox,#con_messagebox,#strCAPTCHA1").val('');
                            $("#lblProcessForm1").html("Thank you for submitting your details. Our representatives will contact you shortly with more information.");
                        } else {
                            $("#lblProcessForm1").html(data);
                        }
                    }
                });

            }

        }

        function con_validatefm() {

            $("#enquireFor3,#con_namebox,#con_emailbox,#con_phonebox,#con_messagebox").css("border-bottom", "1px solid #ccc");
            var enquireFor3 = $("#enquireFor3").val();
            var con_namebox = $("#con_namebox").val();
            var con_emailbox = $("#con_emailbox").val();
            var con_phonebox = $("#con_phonebox").val();
            var con_messagebox = $("#con_messagebox").val();


            if (enquireFor3 == "") {
                $("#enquireFor3").css("border-bottom", "1px solid red");
                $("#enquireFor3").focus();
                return false;
            }
            if (con_namebox == "") {
                $("#con_namebox").css("border-bottom", "1px solid red");
                $("#con_namebox").focus();
                return false;
            }

            if (con_emailbox == "") {
                $("#con_emailbox").css("border-bottom", "1px solid red");
                $("#con_emailbox").focus();

                return false;
            }
            if (IsEmail(con_emailbox) == false) {
                $("#con_emailbox").css("border-bottom", "1px solid red");
                $("#con_emailbox").focus();

                return false;
            }

            if (con_phonebox == "") {
                $("#con_phonebox").css("border-bottom", "1px solid red");
                $("#con_phonebox").focus();
                return false;
            }

            if (IsNumericMobile(con_phonebox) == false) {
                $("#con_phonebox").css("border-bottom", "1px solid red");
                $("#con_phonebox").focus();
                return false;
            }

            if (con_messagebox == "") {
                $("#con_messagebox").css("border-bottom", "1px solid red");
                $("#con_messagebox").focus();
                return false;
            }

            return true;

        }


        function IsEmail(con_emailbox) {
            var regex = /^([a-zA-Z0-9_.+])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(con_emailbox);
        }

        function IsNumericMobile(input) {
            var RE = /\(?([5-9]{1})\)?([ .-]?)([0-9]{5})\2([0-9]{4})/;
            return (RE.test(input));
        }
    </script>


    <!-- lsquare -->
    <script>
        var _paq = _paq || [];
        _paq.push(["setDocumentTitle", document.domain + "/" + document.title]);
        _paq.push(["setCookieDomain", "*.shubhashishhomes.com"]);
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        (function () {
            var u = (("https:" == document.location.protocol) ? "https" : "http") + "://lswebanalytics.com/analytics/";
            _paq.push(['setTrackerUrl', u + 'lsquare.php']);
            _paq.push(['setSiteId', 239]);
            var d = document,
                g = d.createElement('script'),
                s = d.getElementsByTagName('script')[0];
            g.type = 'text/javascript';
            g.defer = true;
            g.async = true;
            g.src = u + 'lsquare.js';
            s.parentNode.insertBefore(g, s);
        })();
    </script>
    <!-- Start of Tawk.to Script -->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function () {
            var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/64b000000000000000000000/1habcdef';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!-- End of Tawk.to Script -->

    <noscript>
        <p><img src="https://lswebanalytics.com/analytics/lsquare.php?idsite=239" style="border:0;" alt=""></p>
    </noscript>
    <!-- End lsquare Code -->

    <script>
        var slideWrapper = $(".main-slider"),
            lazyImages = slideWrapper.find('.slide-image'),
            lazyCounter = 0;

        // When the slide is changing
        function playPauseVideo(slick, control) {
            var currentSlide, slideType, startTime, video;

            currentSlide = slick.find(".slick-current");
            slideType = currentSlide.attr("class").split(" ")[1];
            startTime = currentSlide.data("video-start");

            if (slideType === "video") {
                video = currentSlide.find("video").get(0);
                if (video != null) {
                    if (control === "play") {
                        video.play();
                    } else {
                        video.pause();
                    }
                }
            }
        }

        // DOM Ready
        $(function () {
            // Initialize
            slideWrapper.on("beforeChange", function (event, slick) {
                slick = $(slick.$slider);
                playPauseVideo(slick, "pause");
            });
            slideWrapper.on("afterChange", function (event, slick) {
                slick = $(slick.$slider);
                playPauseVideo(slick, "pause");
            });
            slideWrapper.on("lazyLoaded", function (event, slick, image, imageSource) {
                lazyCounter++;
                console.log(lazyCounter);
                if (lazyCounter === lazyImages.length) {
                    lazyImages.addClass('show');
                    // slideWrapper.slick("slickPlay");
                }
            });

            //start the slider
            slideWrapper.slick({
                // fade:true,
                autoplaySpeed: 120000,
                lazyLoad: "progressive",
                speed: 600,
                arrows: false,
                dots: true,
                cssEase: "cubic-bezier(0.87, 0.03, 0.41, 0.9)"
            });
        });
    </script>
</body>

</html>