
<html lang="en-US" itemscope itemtype="https://www.solarsquare.in">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

<head>
    <link href="/css/app.min.css?id=bc77b2e8ffce3978ddb01eeec11652f9" rel="stylesheet" />
   
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="robots" content="index, follow" />
    <link rel="shortcut icon" href="https://www.solwaveenterprises.com/WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview.png" type="image/x-icon">
    <link rel="icon" href="https://www.solwaveenterprises.com/WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview.png" type="image/x-icon">
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" as="style" onload="this.rel='stylesheet'">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

    <title>Solwave Enteprises</title>
    <meta name="keywords" content="Solwave Enteprises panel for home, solar system for home, solar panel for home price, solar for home, solar panels on roof, solar panels for home cost, solar plant for home, solar panel for home price in india, rooftop panel, Residential Solar Power Systems, Best Home Solar Companies in India, Solar for Housing Societies, Rooftop Solar for Societies, Affordable Solar for Residential Complexes">
    <meta name="description" content="Discover the best rooftop solar panel system for your home. Explore our 0 EMI plans, cyclone-proof installation and expert maintenance.">
    <meta name="image" content="https://sse-website.s3.ap-south-1.amazonaws.com/brands/brand-logo-primary.svg">
    <link rel="canonical" href="https://www.solwaveenterprises.com/" />
    <meta name="ahrefs-site-verification" content="de6efb9f35efa484dadeab6aff812b800392761e12a612d6dbf5bf1ee727c5ca">

    <!--Moenegage-->
    <link rel="preconnect" href="https://cdn.moengage.com/" crossorigin />
    <link rel="dns-prefetch" href="https://cdn.moengage.com/" />
    <link rel="preconnect" href="https://sdk-03.moengage.com/" crossorigin />
    <link rel="dns-prefetch" href="https://sdk-03.moengage.com/" />
    <script src="https://cdn.moengage.com/release/dc_3/versions/2/moe_webSdk_webp.min.latest.js?app_id=3B160S1O9OIFHHNF6D7QAB6A"></script>

    <!-- Facebook Meta Tags -->
    <meta property="og:title" content="Solwave Enterprises - Bharat ki #1 Home Rooftop Solar Company" />
    <meta property="og:url" content="https://www.solwaveenterprises.com/" />
    <meta property="og:description" content="Discover the best rooftop solar panel system for your home. Explore our 0 EMI plans, cyclone-proof installation and expert maintenance." />
    <meta property="og:image" content="https://www.solwaveenterprises.com/WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview.png" />
    <meta property="og:type" content="website" />

    <!-- Twitter Meta Tags -->
    <meta name="twitter:title" content="Solwave Enteprises - Bharat ki #1 Home Rooftop Solar Company" />
    <meta name="twitter:url" content="https://www.solwaveenterprises.com" />
    <meta name="twitter:description" content="Discover the best rooftop solar panel system for your home. Explore our 0 EMI plans, cyclone-proof installation and expert maintenance." />
    <meta name="twitter:image" content="https://www.solarsquare.in/WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview.png" />

    <!-- LinkedIn or Pinterest Meta Tags -->
    <!-- <meta itemprop="name" content="SolarSquare - Bharat ki #1 Home Rooftop Solar Company" />
    <meta itemprop="description" content="Discover the best rooftop solar panel system for your home. Explore our 0 EMI plans, cyclone-proof installation and expert maintenance." />
    <meta itemprop="image" content="https://www.solarsquare.in/images/brand-logo-primary.svg" /> -->
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-162995052-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-162995052-1');
    </script>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-PBS8P6Z');
    </script>
    <!-- End Google Tag Manager -->
    <!-- Start VWO Async SmartCode -->
    <link rel="preconnect" href="https://dev.visualwebsiteoptimizer.com" />
    <script type='text/javascript' data-cfasync="false" id='vwoCode'>
        window._vwo_code || (function() {
            var account_id = 838358,
                version = 2.0,
                settings_tolerance = 2000,
                hide_element = 'body',
                hide_element_style = 'opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important',
                /* DO NOT EDIT BELOW THIS LINE */
                f = false,
                w = window,
                d = document,
                v = d.querySelector('#vwoCode'),
                cK = 'vwo' + account_id + 'settings',
                cc = {};
            try {
                var c = JSON.parse(localStorage.getItem('_vwo' + account_id + 'config'));
                cc = c && typeof c === 'object' ? c : {}
            } catch (e) {}
            var stT = cc.stT === 'session' ? w.sessionStorage : w.localStorage;
            code = {
                use_existing_jquery: function() {
                    return typeof use_existing_jquery !== 'undefined' ? use_existing_jquery : undefined
                },
                library_tolerance: function() {
                    return typeof library_tolerance !== 'undefined' ? library_tolerance : undefined
                },
                settings_tolerance: function() {
                    return cc.sT || settings_tolerance
                },
                hide_element_style: function() {
                    return '{' + (cc.hES || hide_element_style) + '}'
                },
                hide_element: function() {
                    return typeof cc.hE === 'string' ? cc.hE : hide_element
                },
                getVersion: function() {
                    return version
                },
                finish: function() {
                    if (!f) {
                        f = true;
                        var e = d.getElementById('_vis_opt_path_hides');
                        if (e) e.parentNode.removeChild(e)
                    }
                },
                finished: function() {
                    return f
                },
                load: function(e) {
                    var t = this.getSettings(),
                        n = d.createElement('script'),
                        i = this;
                    if (t) {
                        n.textContent = t;
                        d.getElementsByTagName('head')[0].appendChild(n);
                        if (!w.VWO || VWO.caE) {
                            stT.removeItem(cK);
                            i.load(e)
                        }
                    } else {
                        n.fetchPriority = 'high';
                        n.src = e;
                        n.type = 'text/javascript';
                        n.onerror = function() {
                            vwo_code.finish()
                        };
                        d.getElementsByTagName('head')[0].appendChild(n)
                    }
                },
                getSettings: function() {
                    try {
                        var e = stT.getItem(cK);
                        if (!e) {
                            return
                        }
                        e = JSON.parse(e);
                        if (Date.now() > e.e) {
                            stT.removeItem(cK);
                            return
                        }
                        return e.s
                    } catch (e) {
                        return
                    }
                },
                init: function() {
                    if (d.URL.indexOf('vwo_disable') > -1) return;
                    var e = this.settings_tolerance();
                    w._vwo_settings_timer = setTimeout(function() {
                        _vwo_code.finish();
                        stT.removeItem(cK)
                    }, e);
                    var t = d.currentScript,
                        n = d.createElement('style'),
                        i = this.hide_element(),
                        r = t && !t.async && i ? i + this.hide_element_style() : '',
                        c = d.getElementsByTagName('head')[0];
                    n.setAttribute('id', '_vis_opt_path_hides');
                    v && n.setAttribute('nonce', v.nonce);
                    n.setAttribute('type', 'text/css');
                    if (n.styleSheet) n.styleSheet.cssText = r;
                    else n.appendChild(d.createTextNode(r));
                    c.appendChild(n);
                    this.load('https://dev.visualwebsiteoptimizer.com/j.php?a=' + account_id + '&u=' + encodeURIComponent(d.URL) + '&vn=' + version)
                }
            };
            w._vwo_code = code;
            code.init();
        })();
    </script>
    <!-- End VWO Async SmartCode -->
    <!-- Criteo Loader File -->
    <script type="text/javascript" src="//dynamic.criteo.com/js/ld/ld.js?a=117042" async="true"></script>
    <!-- END Criteo Loader File -->
    <!-- Start of MoEngage Code -->
    <script type="text/javascript">
        var moeDataCenter = "dc_3";
        var moeAppID = "3B160S1O9OIFHHNF6D7QAB6A";
        var sdkVersion = "2";

        ! function(e, n, i, t, a, r, o, d) {
            if (!moeDataCenter || !moeDataCenter.match(/^dc_[0-9]+$/gm)) return console.error("Data center has not been passed correctly. Please follow the SDK installation instruction carefully.");
            var s = e[a] = e[a] || [];
            if (s.invoked = 0, s.initialised > 0 || s.invoked > 0) return console.error("MoEngage Web SDK initialised multiple times. Please integrate the Web SDK only once!"), !1;
            e.moengage_object = a;
            var l = {},
                g = function n(i) {
                    return function() {
                        for (var n = arguments.length, t = Array(n), a = 0; a < n; a++) t[a] = arguments[a];
                        (e.moengage_q = e.moengage_q || []).push({
                            f: i,
                            a: t
                        })
                    }
                },
                u = ["track_event", "add_user_attribute", "add_first_name", "add_last_name", "add_email", "add_mobile", "add_user_name", "add_gender", "add_birthday", "destroy_session", "add_unique_user_id", "update_unique_user_id", "moe_events", "call_web_push", "track", "location_type_attribute"],
                m = {
                    onsite: ["getData", "registerCallback"]
                };
            for (var c in u) l[u[c]] = g(u[c]);
            for (var v in m)
                for (var f in m[v]) null == l[v] && (l[v] = {}), l[v][m[v][f]] = g(v + "." + m[v][f]);
            r = n.createElement(i), o = n.getElementsByTagName("head")[0], r.async = 1, r.src = t, o.appendChild(r), e.moe = e.moe || function() {
                return (s.invoked = s.invoked + 1, s.invoked > 1) ? (console.error("MoEngage Web SDK initialised multiple times. Please integrate the Web SDK only once!"), !1) : (d = arguments.length <= 0 ? void 0 : arguments[0], l)
            }, r.addEventListener("load", function() {
                if (d) return e[a] = e.moe(d), e[a].initialised = e[a].initialised + 1 || 1, !0
            }), r.addEventListener("error", function() {
                return console.error("Moengage Web SDK loading failed."), !1
            })
        }(window, document, "script", "https://cdn.moengage.com/release/" + moeDataCenter + "/versions/" + sdkVersion + "/moe_webSdk.min.latest.js", "Moengage");

        Moengage = moe({
            app_id: moeAppID,
            debug_logs: "0"
        });
    </script>
    <!-- End of MoEngage Code -->
</head>
<style>
    /* Prevent horizontal scroll on all screen sizes */
body, html {
  overflow-x: hidden !important;
}

</style>
<!-- Chatbot Toggle Button -->
<!-- Chatbot Toggle Button -->
<div id="chatbot-toggle" onclick="toggleChatbot()">
    <img src="https://cdn-icons-png.flaticon.com/512/4712/4712035.png" alt="ChatBot Icon" width="40" height="40">
</div>

<!-- Chatbot Box -->
<div id="chatbot-box" class="chatbot-hidden">
    <div class="chatbot-header">
        Welcome To Solwave Enterprises
        <span onclick="toggleChatbot()" class="chatbot-close">&times;</span>
    </div>
    <div class="chatbot-body" id="chatbot-body">

        <!-- Enquiry Form -->
        <form class="chatbot-form mt-3" onsubmit="return sendToWhatsApp(event)">
            <input type="text" id="name" placeholder="Your Name" required>
            <input type="tel" id="phone" placeholder="Your Phone" required>
            <textarea id="message" placeholder="Your Message" rows="3" required></textarea>
            <button type="submit">Submit</button>
        </form>

        <div class="chatbot-footer">
            Chatbot designed by Research And Development IT Solution
        </div>
    </div>
</div>

<style>
    #chatbot-toggle {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: white;
        border-radius: 50%;
        cursor: pointer;
        z-index: 9999;
        padding: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        transition: transform 0.3s ease;
    }

    #chatbot-toggle:hover {
        transform: scale(1.1);
    }

    #chatbot-box {
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 320px;
        background-color: #8B0000;
        color: white;
        border-radius: 10px;
        overflow: hidden;
        font-family: Arial, sans-serif;
        z-index: 9999;
        box-shadow: 0 8px 16px rgba(0,0,0,0.4);
        transition: all 0.3s ease;
        display: none;
    }

    .chatbot-visible {
        display: block !important;
    }

    .chatbot-header {
        background-color: #5a0000;
        padding: 12px;
        font-weight: bold;
        font-size: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .chatbot-close {
        cursor: pointer;
        font-size: 20px;
    }

    .chatbot-body {
        padding: 15px;
        max-height: 400px;
        overflow-y: auto;
    }

    .chatbot-form input,
    .chatbot-form textarea {
        width: 100%;
        padding: 6px 10px;
        margin: 5px 0;
        border: none;
        border-radius: 4px;
        font-size: 13px;
    }

    .chatbot-form button {
        width: 100%;
        background-color: white;
        color: darkred;
        padding: 8px;
        border: none;
        border-radius: 4px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 8px;
    }

    .chatbot-footer {
        margin-top: 10px;
        font-size: 11px;
        text-align: center;
        opacity: 0.8;
    }
</style>

<script>
function toggleChatbot() {
    const box = document.getElementById("chatbot-box");
    box.classList.toggle("chatbot-visible");
}

function sendToWhatsApp(event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const message = document.getElementById("message").value.trim();

    if (name && phone && message) {
        const whatsappNumber = "919887005337"; // your WhatsApp with country code
        const text = `Hi, Solwave Enterprise client filled the form from website.%0A%0A*Name:* ${name}%0A*Phone:* ${phone}%0A*Message:* ${message}`;
        const url = `https://wa.me/${whatsappNumber}?text=${text}`;
        window.open(url, "_blank");
    } else {
        alert("Please fill in all fields.");
    }

    return false;
}
</script>





<!-- Auto Show Script -->
<script>
  window.addEventListener("load", function () {
    const modal = new bootstrap.Modal(document.getElementById('projectPopup'));
    modal.show();
  });
</script>

<style>
/* Optional: Smooth modal UI */
.modal-content {
  border-radius: 15px;
  background-color: #fefefe;
}

.card img {
  object-fit: contain;
}

.btn-close {
  background-color: #ddd;
  padding: 8px;
  border-radius: 50%;
}
</style>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PBS8P6Z"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap Navbar</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand" href="#">
      <img src="WhatsApp_Image_2025-07-19_at_12.21.57_PM-removebg-preview (1).png" alt="Logo" height="50">
    </a>

    <!-- Toggle Button -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
      aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="mainNavbar">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>

        <!-- Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="projectsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Projects
          </a>
          <ul class="dropdown-menu" aria-labelledby="projectsDropdown">
            <li><a class="dropdown-item" href="chakra.php">Chekra</a></li>
            <li><a class="dropdown-item" href="behra.php">Behra</a></li>
            <li><a class="dropdown-item" href="binda.php">Binda</a></li>
          </ul>
        </li>

        <li class="nav-item"><a class="nav-link" href="blogs.php">Blogs</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>

        <!-- Enquiry Button -->
        <li class="nav-item">
          <a href="enquiry.php" class="btn btn-danger ms-lg-3">Enquiry Now</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar End -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
    <!-- Overlay for mobile menu -->

    <!-- Mobile navigation menu -->
  
 
<div class="privacy-policy-1">
    <div class="container">
        <h2 class="sse-slider-header-1 text-center">Contact Us</h2>
    </div>
</div>
<!-- ðŸŒž Solar Project Showcase Section -->
<!-- ✅ Bootstrap CDN -->



<!-- âœ… Logo Section -->



 
</style>
<!-- âœ… Solar Solutions Section -->






    
    
    







<!DOCTYPE html>

  <!-- Bootstrap CSS (CDN) -->
  
  
  <!-- Counter Script -->


  <!-- Bootstrap JS (optional, if using any interactive components) -->
  

</style>

<section class="contact-section py-5">
  <div class="container">
    <h3 class="section-title text-center mb-4" style="color:black">Contact Us</h3>
    <div class="row g-4 justify-content-center">

      <!-- Address -->
      <div class="col-12 col-md-4">
        <div class="contact-card text-center p-4">
          <i class="fas fa-map-marker-alt contact-icon"></i>
          <h5 class="mt-3">Address</h5>
          <p>E-52, Amrapali Marg, Vaishali Nagar, Jaipur-302021</p>
        </div>
      </div>

      <!-- Email -->
      <div class="col-12 col-md-4">
        <div class="contact-card text-center p-4" style="height:182px">
          <i class="fas fa-envelope contact-icon"></i>
          <h5 class="mt-3">Email</h5>
          <p><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="aad9c5c6dccfcfc4decfd8dad8c3d9cfd9eacfd2cbc7dac6cf84c9c5c7">[email&#160;protected]</a></p>
        </div>
      </div>

      <!-- Phone -->
      <div class="col-12 col-md-4">
        <div class="contact-card text-center p-4"  style="height:182px">
          <i class="fas fa-phone contact-icon"></i>
          <h5 class="mt-3">Phone</h5>
          <p><a href="tel:+919351953802">+91 9351953802</a></p>
        </div>
      </div>

    </div>
  </div>
</section>

<style>
.contact-section {
  
  color: #fff;
}

.section-title {
  font-size: 28px;
  font-weight: 700;
}

.contact-card {
  background: hsl(353.22deg 57.79% 39.02%);
  border-radius: 20px;
  box-shadow: 0 8px 25px rgba(0,0,0,0.3);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.contact-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 15px 35px rgba(0,0,0,0.5);
}

.contact-icon {
  font-size: 36px;
  color: hsl(353.22deg 57.79% 39.02%);
  transition: transform 0.3s ease, color 0.3s ease;
}

.contact-card:hover .contact-icon {
  transform: scale(1.2);
  color: #fff;
}

.contact-card h5 {
  font-size: 18px;
  font-weight: 600;
  margin-top: 10px;
}

.contact-card p {
  margin-top: 5px;
  font-size: 15px;
}

.contact-card a {
  color: #fff;
  text-decoration: none;
  transition: color 0.3s;
}

.contact-card a:hover {
  color: hsl(353.22deg 57.79% 39.02%);
}

/* Responsive for mobile */
@media(max-width:767px){
  .contact-card {
    padding: 25px 15px;
  }
}

</style>

<section class="contact-map-section py-5">
  <div class="container">
    <div class="row g-4 align-items-start">

      <!-- Left Side: Map -->
      <div class="col-12 col-lg-6">
        <div class="map-wrapper">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.0536683574023!2d75.7025033!3d26.9017918!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db4a157c51ae1%3A0x1b71e7a42fcc7e!2sSolwave%20Enterprises!5e0!3m2!1sen!2sin!4v1752921392680!5m2!1sen!2sin"
            frameborder="0"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>

      <!-- Right Side: Contact Form -->
      <div class="col-12 col-lg-6">
        <div class="contact-form-wrapper p-4 rounded shadow-sm">
          <h3 class="mb-4">Get In Touch</h3>
          <form>
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input type="text" class="form-control" id="name" placeholder="Your Name">
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" id="email" placeholder="you@example.com">
            </div>
            <div class="mb-3">
              <label for="phone" class="form-label">Phone</label>
              <input type="tel" class="form-control" id="phone" placeholder="+91 9XXXXXXXXX">
            </div>
            <div class="mb-3">
              <label for="message" class="form-label">Message</label>
              <textarea class="form-control" id="message" rows="4" placeholder="Your message"></textarea>
            </div>
            <button type="submit" class="btn-submit">Send Message</button>
          </form>
        </div>
      </div>

    </div>
  </div>
</section>

<style>
.contact-map-section {
  
  color: #fff;
}

.map-wrapper iframe {
  width: 100%;
  height: 450px;
  border: 0;
  border-radius: 20px;
}

.contact-form-wrapper {
  background: hsl(353.22deg 57.79% 39.02%);
  color: #fff;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
}

.contact-form-wrapper h3 {
  font-weight: 700;
}

.contact-form-wrapper .form-control {
  border-radius: 10px;
  border: none;
}

.contact-form-wrapper .form-control:focus {
  box-shadow: none;
  border-color: #fff;
}

.btn-submit {
  background: #fff;
  color: hsl(353.22deg 57.79% 39.02%);
  font-weight: 600;
  padding: 10px 25px;
  border-radius: 10px;
  border: none;
  transition: transform 0.3s ease, background 0.3s ease;
}

.btn-submit:hover {
  background: #f0f0f0;
  transform: translateY(-3px);
}

/* Responsive */
@media(max-width: 991px){
  .map-wrapper iframe {
    height: 300px;
  }
  .contact-form-wrapper {
    padding: 20px;
  }
}
</style>

       
                   <div class="footer">
    <div class="container">
        <div class="row py-5 custom-padding align-items-start">

            <!-- Brand & Contact -->
            <div class="col-12 col-md-5 mb-4 mb-md-0">
                <div class="footer-brand">
                    <h3 style="color:white">Solwave Enterprises</h3>
                    <p class="footer-slogan">
                        Rooftop solar made simple. We don't just sell solar — we give you peace of mind.
                    </p>
                </div>

                <!-- Contact Info -->
                <div class="footer-contact mt-4">
                    <div class="d-flex align-items-center mb-2">
                        <i class="fa fa-phone me-2"></i>
                        <a href="tel:+919351953802">+91 9351953802</a>
                    </div>
                    <div class="d-flex align-items-center mb-2">
                        <i class="fa fa-envelope me-2"></i>
                        <a href="/cdn-cgi/l/email-protection#295a46455f4c4c475d4c5b595b405a4c5a074a4644">solveenterprises.com</a>
                    </div>

                    <!-- Social Icons -->
                    <div class="footer-social mt-3 d-flex gap-3">
                        <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                        <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                        <a href="https://www.instagram.com/solwave.enterprises2025/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.linkedin.com/in/solwave-enterprises-252065375/" target="_blank"><i class="fa fa-linkedin"></i></a>
                    </div>
                </div>

                <!-- Address for Mobile -->
                <div class="footer-address mt-4 d-md-none">
                    E-52, Amrapali Marg, Vaishali Nagar, Jaipur-302021
                </div>
            </div>

            <!-- Links -->
            <div class="col-12 col-md-7 footer-links">
                <div class="row">
                    <div class="col-6 col-md-4 mb-3 mb-md-0">
                        <h5 style="color:white">Our Projects</h5>
                        <ul>
                            <li><a href="index.php">Homes</a></li>
                            <li><a href="commercial.php">Commercial</a></li>
                            <li><a href="jjm.php">JJM</a></li>
                        </ul>
                    </div>
                    <div class="col-6 col-md-4 mb-3 mb-md-0">
                        <h5 style="color:white">Quick Links</h5>
                        <ul>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="blogs.php">Blogs</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-4">
                        <h5 style="color:white">Others</h5>
                        <ul>
                            <li><a href="chekra.php">Chekra Solar</a></li>
                            <li><a href="binda.php">Binda</a></li>
                            <li><a href="behra.php">Behra</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Address for Desktop -->
                <div class="footer-address mt-4 d-none d-md-block">
                    E-52, Amrapali Marg, Vaishali Nagar, Jaipur-302021
                </div>
            </div>

            <!-- Copyright -->
            <div class="col-12 text-center mt-4">
                <p>&copy; 2025 Solwave Enterprises. Designed by Research And Development IT Solutions.</p>
            </div>
        </div>
    </div>
</div>

<style>
/* Footer Main */
.footer {
    background: hsl(353.22deg 57.79% 39.02%);
    color: #fff;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    padding-top: 40px;
}

.footer h3, .footer h5 {
    color: #ff5e78;
}

.footer h5 {
    font-weight: 600;
    margin-bottom: 15px;
}

.footer a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease, transform 0.3s ease;
}

.footer a:hover {
    color: #ff5e78;
    transform: translateY(-2px);
}

.footer-slogan {
    font-size: 15px;
    line-height: 1.6;
}

.footer-contact i {
    color: #ff5e78;
    font-size: 18px;
}

.footer-social i {
    font-size: 20px;
    color: #fff;
    transition: color 0.3s, transform 0.3s;
}

.footer-social i:hover {
    color: #ff5e78;
    transform: scale(1.2);
}

.footer ul {
    list-style: none;
    padding: 0;
}

.footer ul li {
    margin-bottom: 8px;
}

.footer-address {
    font-size: 14px;
    margin-top: 10px;
    color: #aaa;
}

@media (max-width: 767px) {
    .footer-links .col-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }
    .footer h3 {
        text-align: center;
    }
    .footer-slogan {
        text-align: center;
    }
    .footer-social {
        justify-content: center;
    }
}
</style>


    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="/js/app.min.js?id=cdb0ed44477d2143d02d1e3ce7c655ad"></script>
    <script src="/js/slick.min.js?id=483a3731bbe7046c1da3163da76dbe98"></script>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            const youtubePlayer = document.getElementById('yt-player');

            setTimeout(() => {
                const iframe = youtubePlayer.querySelector('iframe');
                const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
                const youtubeLink = iframeDocument.querySelector('.youtubeembed');
                if (youtubeLink) {
                    let hasTracked = false;
                    youtubeLink.addEventListener('click', function(e) {
                        if (!hasTracked) {
                            try {
                                const moengagePayload = {
                                    'CTA Name': 'customer_review_video',
                                    'page_source': page_source || '',
                                    'device_type': device_type || '',
                                    'device_name': device_name || '',
                                    'previous_page_source': previousPage,
                                    'utm_source': window.utmParams.utm_source || '',
                                    'utm_medium': window.utmParams.utm_medium || '',
                                    'utm_campaign': window.utmParams.utm_campaign || '',
                                    'utm_content': window.utmParams.utm_content || '',
                                    'utm_fbclid': window.utmParams.fbclid || '',
                                }
                                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                                // console.log('Moengage payload: ', moengagePayload);
                                Moengage.track_event('cta_clicked', moengagePayload);
                                hasTracked = true;

                            } catch (error) {
                                console.error('Error tracking video click:', error);
                            }
                        }
                    });
                } else {
                    console.error('YouTube embed link not found');
                }
            }, 500);
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('#general-tab,#faq-general').click(function(e) {
                const moengagePayload = {
                    'CTA Name': `faq_general`,
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'faq_name': 'general',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: faq_general ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
            });

            $('#solar-economics-tab,#faq-solar-economics').click(function(e) {
                const moengagePayload = {
                    'CTA Name': `faq_solar_economics`,
                    'faq_name': 'solar-economics',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: solar-economics-tab ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
            });

            $('#solar-maintenance-tab,#faq-solar-maintenance').click(function(e) {
                const moengagePayload = {
                    'CTA Name': `faq_solar_maintenance`,
                    'faq_name': 'solar-maintenance',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: faq-solar-maintenance ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('.track-news').click(function(e) {
                e.preventDefault();
                const news_title = $(this).data('news-title') || "NA";
                const moengagePayload = {
                    'CTA Name': 'news_article',
                    'news_article_name': news_title || '',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                }
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.open($(this).attr('href'), '_blank');
            })

        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('#read-more-btn').click(function(e) {
                const moengagePayload = {
                    'CTA Name': 'read_more',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                }
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
            })
        })
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('#footer-banner-link').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'sticky_footer_book_a_free_consultation',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.location.href = $(this).attr('href');

            })
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#homes-moe').click(function(e) {
                e.preventDefault();
                const url = window.location.href;
                const page_source = getRouteFromUrl(url);
                const device_type = getDeviceType();
                const device_name = getDeviceName();
                const previousPage = getRouteFromUrl("");
                const moengagePayload = {
                    'CTA Name': 'our_solution_homes',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.location.href = $(this).attr('href');
            })
            $('#hs-moe').click(function(e) {
                e.preventDefault();
                const url = window.location.href;
                const page_source = getRouteFromUrl(url);
                const device_type = getDeviceType();
                const device_name = getDeviceName();
                const previousPage = getRouteFromUrl("");
                const moengagePayload = {
                    'CTA Name': 'our_solution_housing_society',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.location.href = $(this).attr('href');
            });
            $('#comm-moe').click(function(e) {
                e.preventDefault();
                const url = window.location.href;
                const page_source = getRouteFromUrl(url);
                const device_type = getDeviceType();
                const device_name = getDeviceName();
                const previousPage = getRouteFromUrl("");
                const moengagePayload = {
                    'CTA Name': 'our_solution_commercial',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.location.href = $(this).attr('href');
            });


            $('#go-solar-btn').click(function(e) {
                e.preventDefault();
                const url = window.location.href;
                const page_source = getRouteFromUrl(url);
                const device_type = getDeviceType();
                const device_name = getDeviceName();
                const previousPage = getRouteFromUrl("");
                console.log('Previous page: ', previousPage);
                const moengagePayload = {
                    'CTA Name': 'banner_get_a_quote',
                    'page_source': page_source || '',
                    'previous_page_source': previousPage,
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                console.log('Moengage payload: ', moengagePayload);
                Moengage.track_event('cta_clicked', moengagePayload);
                window.location.href = $(this).attr('href');
            });
            window.criteo_q = window.criteo_q || [];
            let deviceType = /iPad/.test(navigator.userAgent) ? "t" : /Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk/.test(navigator.userAgent) ? "m" : "d";
            window.criteo_q.push({
                event: "setAccount",
                account: 117042
            }, {
                event: "setEmail",
                email: ""
            }, {
                event: "setSiteType",
                type: deviceType
            }, {
                event: "viewHome"
            });

            const EVENT_NAME = 'page_viewed';
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);

            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            const moengagePayload = {
                'page_source': page_source || '',
                'device_type': device_type || '',
                'device_name': device_name || '',
                'previous_page_source': previousPage,
                'utm_source': window.utmParams.utm_source || '',
                'utm_medium': window.utmParams.utm_medium || '',
                'utm_campaign': window.utmParams.utm_campaign || '',
                'utm_content': window.utmParams.utm_content || '',
                'utm_fbclid': window.utmParams.fbclid || '',
            }
            Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
            // console.log('Moengage payload: ', moengagePayload);
            Moengage.track_event(EVENT_NAME, moengagePayload);
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let sseDesktopLogo = document.getElementById('sse-desktop-logo');
            if (sseDesktopLogo) {
                sseDesktopLogo.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'company_logo',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload: ',JSON.stringify(moengagePayload));
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in";
                });
            }

            let hamburgerMenu = document.getElementById('hamburger-menu');
            if (hamburgerMenu) {
                hamburgerMenu.addEventListener('click', function() {
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'hamburger_menu',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload: hamburger_menu ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                });
            }

            let signupElectricityCtaMob = document.getElementById('signup-electricity-cta-mobile');
            if (signupElectricityCtaMob) {
                signupElectricityCtaMob.addEventListener('click', function(e) {
                    e.preventDefault();
                    // console.log("Sign up for free electricity clicked");
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'sign_up_for_free_electricity',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload: sign_up_for_free_electricity mobile', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/go-solar";
                })
            }

            let signupElectricityCta = document.getElementById('signup-electricity-cta');
            if (signupElectricityCta) {
                signupElectricityCta.addEventListener('click', function(e) {
                    e.preventDefault();
                    // console.log("Sign up for free electricity clicked");
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'sign_up_for_free_electricity',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload: sign_up_for_free_electricity ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/go-solar";
                })
            };

            const sseHomes = document.getElementById('sse-homes');
            if (sseHomes) {
                sseHomes.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_homes',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_homes: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/homes";
                });
            }

            const sseHomesMobiles = document.getElementById('sse-homes-mobile');
            if (sseHomesMobiles) {

                sseHomesMobiles.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_homes',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_homes mobile: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/homes";
                });
            }

            const sseHousingSociety = document.getElementById('sse-housing-society');
            if (sseHousingSociety) {
                sseHousingSociety.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_housing_society',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_housing_society: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/housing-society";
                });
            }

            const sseHousingSocietyMobile = document.getElementById('sse-housing-society-mobile');
            if (sseHousingSocietyMobile) {
                sseHousingSocietyMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_housing_society',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_housing_society: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/housing-society";
                });
            }

            const sseCommercial = document.getElementById('sse-commercial');
            if (sseCommercial) {
                sseCommercial.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_commercial',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_commercial: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/commercial";
                });
            }

            const sseCommercialMobile = document.getElementById('sse-commercial-mobile');
            if (sseCommercialMobile) {
                sseCommercialMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_commercial',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_commercial mobile: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/commercial";
                });
            }



            const sseAboutUs = document.getElementById('sse-about-us');
            if (sseAboutUs) {
                sseAboutUs.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_about_us',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_about_us: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/about-us";
                });

            }

            const sseAboutUsMobile = document.getElementById('sse-about-us-mobile');
            if (sseAboutUsMobile) {
                sseAboutUsMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_about_us',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_about_us mobile: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/about-us";
                });
            }

            const sseCareers = document.getElementById('sse-careers');
            if (sseCareers) {
                sseCareers.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_careers',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_careers: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://recruitcareers.zappyhire.com/en/solarsquare";
                })
            }

            const sseCareersMobile = document.getElementById('sse-careers-mobile');
            if (sseCareersMobile) {
                sseCareersMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_careers',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };

                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_careers: mobile ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://recruitcareers.zappyhire.com/en/solarsquare";
                })
            }


            const sseSolarProPartner = document.getElementById('sse-solarProPartner');
            if (sseSolarProPartner) {
                sseSolarProPartner.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_solarpro',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_careers: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/solar-pro";
                })
            }

            const sseSolarProPartnerMobile = document.getElementById('sse-solar-pro-mobile');
            if (sseSolarProPartnerMobile) {
                sseSolarProPartnerMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_solarpro',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_solarpro: mobile ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/solar-pro";
                })
            }

            const sseBlog = document.getElementById('sse-blog');
            if (sseBlog) {
                sseBlog.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_blog',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_blog: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://solarsquare.in/blog";
                })
            }

            const sseBlogMobile = document.getElementById('sse-blog-mobile');
            if (sseBlogMobile) {
                sseBlogMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_blog',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_blog: mobile ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://solarsquare.in/blog";
                })
            }

            const sseCalc = document.getElementById('sse-solar-calc');
            if (sseCalc) {
                sseCalc.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_solar_calculator',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_blog: ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/blog/solar-calculator";
                })
            }


            const sseCalcMobile = document.getElementById('sse-solar-calc-mobile');
            if (sseCalcMobile) {
                sseCalcMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = window.location.href;
                    const page_source = getRouteFromUrl(url);
                    const device_type = getDeviceType();
                    const device_name = getDeviceName();
                    const previousPage = getRouteFromUrl("");

                    const moengagePayload = {
                        'CTA Name': 'header_solar_calculator',
                        'page_source': page_source || '',
                        'device_type': device_type || '',
                        'device_name': device_name || '',
                        'previous_page_source': previousPage,
                        'utm_source': window.utmParams.utm_source || '',
                        'utm_medium': window.utmParams.utm_medium || '',
                        'utm_campaign': window.utmParams.utm_campaign || '',
                        'utm_content': window.utmParams.utm_content || '',
                        'utm_fbclid': window.utmParams.fbclid || '',
                    };
                    Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                    // console.log('Moengage payload for header_blog: mobile ', moengagePayload);
                    const EVENT_NAME = 'cta_clicked';
                    Moengage.track_event(EVENT_NAME, moengagePayload);
                    window.location.href = "https://www.solarsquare.in/blog/solar-calculator";
                })
            }


        })
    </script>
    <script>
        function handleCitiesMoreClick(event) {
            event.preventDefault();

            const offcanvasEl = document.querySelector('#offcanvasTop');
            const offcanvasInstance = bootstrap.Offcanvas.getInstance(offcanvasEl);
            if (offcanvasInstance) {
                offcanvasInstance.hide();
                const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                backdrops.forEach((backdrop) => {
                    if (backdrop) {
                        backdrop.remove();
                    }
                });
            }
            setTimeout(() => {
                const target = document.querySelector('#footer-locations-href');
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                } else {
                    window.location.href = 'footer-locations-href';
                }
            }, 300);
        }
    </script>


    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('#footer-homes,#footer-homes-mobile').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_homes',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_homes', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/homes";
            });

            $('#footer-commercial,#footer-commercial-mobile').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_commercial',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_commercial', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/commercial";
            })

            $('#footer-about-us-mobile,#footer-about-us').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_about_us',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_about_us', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/about-us";
            });

            $('#footer-careers,#footer-careers-mobile').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_careers',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_careers', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://recruitcareers.zappyhire.com/en/solarsquare";
            });

            $('#footer-solar-pro, #footer-solar-pro-mobile').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_solarpro',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_solarpro', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/solar-pro";
            });

            $('#footer-on-grid-mobile,#footer-on-grid').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_on_grid_solar',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_on_grid_solar', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/pages/on-grid-solar-system";
            });

            $('#footer-off-grid,#footer-off-grid-mobile').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_off_grid_solar',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_off_grid_solar', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/pages/off-grid-solar-system";
            })

            $('#facebook-footer,#facebook-footer-mob').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_facebook',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_facebook', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.open("https://www.facebook.com/SolarSquareEnergy/", "_blank");
            });

            $('#youtube-footer,#youtube-footer-mob').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_youtube',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_youtube', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.open("https://www.youtube.com/channel/UCd7MXs59gW3HZPbtm6giExQ", "_blank");
            });

            $('#insta-footer,#insta-footer-mob').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_instagram',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_instagram', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.open("https://www.instagram.com/solar.square/", "_blank");
            });

            $('#linkedin-footer,#linkedin-footer-mob').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_linkedin',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: in footer_linkedin', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.open("https://www.linkedin.com/company/solarsquare-energy-private-limited", "_blank");
            });

        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            $('#footer-privacy-policy').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_privacy_policy',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };

                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/privacy-policy";
            })

            $('#footer-terms-service').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_terms_of_service',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };

                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: footer_terms_service ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/terms-of-use";
            });

            $('#footer-good-zero').click(function(e) {
                e.preventDefault();
                const moengagePayload = {
                    'CTA Name': 'footer_tnc_goodzero',
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                };

                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: footer_tnc_goodzero ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = "https://www.solarsquare.in/goodzero-terms-of-use";
            });

            $('#footer-delhi-cities').click(function(e) {
                e.preventDefault();
                var cityName = $(this).find('span').text().trim().split(' ')[2].toLowerCase();
                const moengagePayload = {
                    'CTA Name': `footer_solar_in_${cityName}`,
                    'page_source': page_source || '',
                    'device_type': device_type || '',
                    'device_name': device_name || '',
                    'previous_page_source': previousPage,
                    'utm_source': window.utmParams.utm_source || '',
                    'utm_medium': window.utmParams.utm_medium || '',
                    'utm_campaign': window.utmParams.utm_campaign || '',
                    'utm_content': window.utmParams.utm_content || '',
                    'utm_fbclid': window.utmParams.fbclid || '',
                    'city_name': cityName || '',
                };
                Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
                // console.log('Moengage payload: footer_solar_in_delhi ', moengagePayload);
                const EVENT_NAME = 'cta_clicked';
                Moengage.track_event(EVENT_NAME, moengagePayload);
                window.location.href = $(this).attr('href');
            });
        });
    </script>
    <script type="text/javascript">
        $(document).on('click', '[id^="cities-footer-"]', function(e) {
            e.preventDefault();
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            let cityText = $(this).find('span').text().trim();
            let cityName = cityText.replace(/^Solar in\s+/i, '');
            let formattedCity = cityName.toLowerCase().replace(/\s+/g, '_');
            const moengagePayload = {
                'CTA Name': `footer_solar_in_${formattedCity}`,
                'page_source': page_source || '',
                'device_type': device_type || '',
                'device_name': device_name || '',
                'previous_page_source': previousPage,
                'utm_source': window.utmParams.utm_source || '',
                'utm_medium': window.utmParams.utm_medium || '',
                'utm_campaign': window.utmParams.utm_campaign || '',
                'utm_content': window.utmParams.utm_content || '',
                'utm_fbclid': window.utmParams.fbclid || '',
            };
            Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
            // console.log('Moengage payload: footer_solar_in_city ', JSON.stringify(moengagePayload));
            const EVENT_NAME = 'cta_clicked';
            Moengage.track_event(EVENT_NAME, moengagePayload);
            window.location.href = $(this).attr('href');
        })
    </script>
    <script type="text/javascript">
        $(document).on('click', '[id^="state-footer-"]', function(e) {
            e.preventDefault();
            const url = window.location.href;
            const page_source = getRouteFromUrl(url);
            const device_type = getDeviceType();
            const device_name = getDeviceName();
            const previousPage = getRouteFromUrl("");

            let stateText = $(this).find('span').text().trim();
            let formattedState = stateText.toLowerCase().replace(/\s+/g, '_');
            const moengagePayload = {
                'CTA Name': `footer_solar_in_${formattedState}`,
                'page_source': page_source || '',
                'device_type': device_type || '',
                'device_name': device_name || '',
                'previous_page_source': previousPage,
                'utm_source': window.utmParams.utm_source || '',
                'utm_medium': window.utmParams.utm_medium || '',
                'utm_campaign': window.utmParams.utm_campaign || '',
                'utm_content': window.utmParams.utm_content || '',
                'utm_fbclid': window.utmParams.fbclid || '',
            };
            Object.keys(moengagePayload).forEach((key) => (moengagePayload[key] == null || moengagePayload[key] == '') && delete moengagePayload[key]);
            // console.log('Moengage payload: footer_solar_in_state ', moengagePayload);
            const EVENT_NAME = 'cta_clicked';
            Moengage.track_event(EVENT_NAME, moengagePayload);
            window.location.href = $(this).attr('href');
        });
    </script>
    <script>
        window.utmParams = {
            utm_source: "",
            utm_medium: "",
            utm_campaign: "",
            utm_content: "",
            utm_term: "",
            fbclid: ""
        };
        document.fonts.ready.then(() => {
            document.querySelectorAll('.material-symbols-outlined').forEach((element) => {
                element.classList.add('font-loaded');
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            const currentUrl = window.location.pathname;
            const callNowBtnM = document.getElementById("callNowBtnM");
            const callNowBtnW = document.getElementById("callNowBtnW");

            // if (currentUrl === "/rooftop-solar-in-india") {
            //     callNowBtnM.style.display = "block"; // Show the button
            //     callNowBtnW.style.display = "block"; // Show the button
            // }
            $('#mainCTA').on('click', function(event) {
                event.stopPropagation();
                event.stopImmediatePropagation();
                $('#mobileNav').removeClass('show')
            });
            $(".get-started-img-block").hover(
                function() {
                    $(".get-started-img-block").removeClass('active');
                    $(this).addClass('active');
                }
            );

            $('.testimonials-carousel').slick({
                slidesToShow: 2,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: false,
                vertical: true,
                verticalSwiping: true,
                dots: false,
                pauseOnHover: true,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        verticalSwiping: false
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 1,
                        verticalSwiping: false
                    }
                }]
            });

            $('.m-testimonials-carousel').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: true,
                dots: true,
                pauseOnHover: true
            });

            $('.sp-cities').slick({
                slidesToShow: 6,
                slidesToScroll: 3,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: false,
                dots: true,
                pauseOnHover: true,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 4
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 3
                    }
                }]
            });

            $('.customer-logos').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 1500,
                arrows: false,
                dots: false,
                pauseOnHover: true,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 4
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 2
                    }
                }]
            });

            $('.in-news-slider').slick({
                slidesToShow: 3,
                slidesToScroll: 3,
                autoplay: true,
                autoplaySpeed: 2500,
                arrows: false,
                dots: true,
                pauseOnHover: true,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToScroll: 1,
                        slidesToShow: 1,
                        dots: false
                    }
                }]
            });

            $('.slick-go-to-previous').on('click', function(event) {
                event.stopPropagation();
                event.stopImmediatePropagation();
                $('.testimonials-carousel').slick('slickPrev');
            });

            $('.slick-go-to-next').on('click', function(event) {
                event.stopPropagation();
                event.stopImmediatePropagation();
                $('.testimonials-carousel').slick('slickNext');
            });

            $('form input[type=text]').focus(function() {
                $(this).siblings(".alert").hide();
            });
            $('.custom-radio').click(function(e) {
                e.preventDefault();
                $("#homes_bill").val($(this).attr("data-value"));
            })
            $('.custom-radio-hs').click(function(e) {
                e.preventDefault();
                $("#designation").val($(this).attr("data-value"));
            })
            $('.custom-radio-block').click(function() {
                $(this).siblings(".alert").hide();
            });

            const $mobileNav = $("#mobileNav");
            const $mobileNavClose = $("#mobileNavClose");

            function openMobileNav() {
                $mobileNav.addClass("show");
            }

            function closeMobileNav() {
                $mobileNav.removeClass("show");
            }
            // $(".navbar-toggler").on("click", openMobileNav);
            $mobileNavClose.on("click", closeMobileNav);

            $.fn.isInViewport = function() {
                var elementTop = $(this).offset().top;
                var elementBottom = elementTop + $(this).outerHeight();
                var viewportTop = $(window).scrollTop();
                var viewportBottom = viewportTop + $(window).height();
                return elementBottom > viewportTop && elementTop < viewportBottom;
            };

            $('.radio-group .custom-radio').click(function() {
                $(this).parent().find('.custom-radio').removeClass('selected');
                $(this).addClass('selected');
                var val = $(this).attr('data-value');
                $(this).parent().find('input').val(val);
                $(this).parent().find('label').remove();
            });

            $('.wrapper-select .radio-group .custom-radio').click(function() {
                $(this).parent().find('.custom-radio').removeClass('selected-v2');
                $(this).addClass('selected-v2');
                var val = $(this).attr('data-value');
                $(this).parent().find('input').val(val);
                $(this).parent().find('label').remove();
            });

            $('.test-slider').slick({
                dots: true,
                infinite: true,
                centerMode: true,
                slidesToShow: 3,
                slidesToScroll: 5,
                autoplay: true,
                responsive: [{
                        breakpoint: 768,
                        settings: {
                            autoplay: true,
                            arrows: false,
                            centerMode: true,
                            slidesToShow: 1,
                            slidesToScroll: 5,
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            autoplay: true,
                            arrows: false,
                            centerMode: true,
                            slidesToShow: 1,
                            slidesToScroll: 5,
                        }
                    }
                ]
            }).on('afterChange', function(event, slick, direction) {
                if (direction === 0) {
                    $('.hs-carousel-head').text('Sobha Dewflower, Bengaluru');
                    $('.hs-carousel-subhead').text('148 kW rooftop solar, August 2021');
                }
                if (direction === 1) {
                    $('.hs-carousel-head').text('Maurishka Palace, Mangalore');
                    $('.hs-carousel-subhead').text('140 kW rooftop solar, September 2020');
                }
                if (direction === 2) {
                    $('.hs-carousel-head').text('Shriram Whitehouse, Bengaluru');
                    $('.hs-carousel-subhead').text('174 kW rooftop solar, September 2021');
                }
                if (direction === 3) {
                    $('.hs-carousel-head').text('Century celeste');
                    $('.hs-carousel-subhead').text('148 kW rooftop solar, August 2021');
                }
                if (direction === 4) {
                    $('.hs-carousel-head').text('Purva Fairmont, Bengaluru');
                    $('.hs-carousel-subhead').text('193 kW rooftop solar,   May 2021');
                }
            });
        });
        if (!sessionStorage.getItem("original_referrer")) {
            const ref = document.referrer;
            const sameDomain = ref.includes(location.hostname);
            if (ref && !sameDomain) {
                sessionStorage.setItem("original_referrer", ref);
            } else {
                sessionStorage.setItem("original_referrer", ""); // mark as direct
            }
        }
    </script>
</body>

</html>

<div class="facebook_float">
                        <a href="#">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/2021_Facebook_icon.svg/2048px-2021_Facebook_icon.svg.png" style="height:30px">
                        </a>
                    </div>
                    
                    <div class="insta_float">
                        <a href="https://www.instagram.com/solwave.enterprises2025/">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/600px-Instagram_icon.png" alt="whatspp" width="30px" class="facebook_float_btn" style="height:30px">
                        </a>
                    </div>
                    
                  <div class="whatsapp_float">
    <a href="https://wa.me/919887005337?text=Welcome%20to%20Solwave enterprises" target="_blank">
        <img src="whatsapp (1).png" alt="whatsapp" width="30px" height="30px" class="facebook_float_btn" style="height:30px;">
    </a>
</div>

                    
                    <style>
                        .whatsapp_float {
                            position: fixed;
                            bottom: 140px;
                            right: 5px;

                        }

                        .link_float {
                            position: fixed;
                            bottom: 280px;
                            right: 5px;
                        }

                        .insta_float {
                            position: fixed;
                            bottom: 190px;
                            right: 5px;
                        }

                        .youtube_float {
                            position: fixed;
                            bottom: 200px;
                            right: 5px;
                        }

                        .facebook_float {
                            position: fixed;
                            bottom: 240px;
                            right: 5px;

                        }

                        .pinterest_float {
                            position: fixed;
                            bottom: 150px;
                            right: 5px;

                        }
                        .facebook_float,
.insta_float,
.whatsapp_float {
    position: fixed;
    right: 5px;
    z-index: 9999; /* make sure they stay on top */
}
                    </style>